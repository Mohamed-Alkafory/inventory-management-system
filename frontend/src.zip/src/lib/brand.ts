export const BRAND = "Prodexa";
